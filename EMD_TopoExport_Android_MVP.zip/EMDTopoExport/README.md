# EMD TopoExport

Android MVP for an online-map topographic survey workflow.

## Current MVP
- Interactive OpenStreetMap raster map
- GPS jump-to-position
- Tap-to-collect points
- Automatic DXF export to Downloads/EMD TopoExport
- Point and label layers in DXF

## Planned production modules
1. Online terrain/DEM service
2. DEM download for user-selected AOI
3. Contour generation (0.5/1/2/5/10 m)
4. OSM vector extraction for roads/buildings/water
5. Coordinate system selector (EPSG)
6. UTM/local-grid transformation
7. Polygon/boundary/breakline tools
8. GeoJSON/KML/LandXML/PDF/GeoTIFF/GLB exports
9. RTK Bluetooth/NTRIP support
10. Project database and automatic backup

## Data-source plan
- Basemap: OpenStreetMap or a commercial OSM-derived tile/vector provider.
- Global DEM fallback: Copernicus DEM GLO-30 (30 m global coverage).
- Higher-resolution Philippines source: integrate licensed/authorized NAMRIA/Phil-LiDAR/other DEM services where access permits.
- Satellite imagery: use a licensed imagery provider; do not scrape imagery.

## Important CRS note
The MVP writes longitude/latitude directly to DXF for demonstration. For engineering/survey use,
the production version must transform coordinates into a projected CRS selected by the user
(for example the appropriate UTM zone) and preserve vertical datum metadata.

## Build
Open this folder in Android Studio and let Gradle sync. Build/install on an Android device.
