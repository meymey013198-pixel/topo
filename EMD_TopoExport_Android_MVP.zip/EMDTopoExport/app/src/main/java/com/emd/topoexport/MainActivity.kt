package com.emd.topoexport

import android.Manifest
import android.content.pm.PackageManager
import android.location.Location
import android.os.Bundle
import android.os.Environment
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import com.emd.topoexport.dxf.DxfWriter
import org.maplibre.android.MapLibre
import org.maplibre.android.geometry.LatLng
import org.maplibre.android.maps.MapView
import org.maplibre.android.maps.Style
import org.maplibre.android.annotations.MarkerOptions
import java.io.File

class MainActivity : AppCompatActivity() {
    private lateinit var mapView: MapView
    private lateinit var status: TextView
    private val points = mutableListOf<LatLng>()
    private var drawing = false
    private val locationRequestCode = 501

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        MapLibre.getInstance(this)
        setContentView(R.layout.activity_main)

        mapView = findViewById(R.id.mapView)
        status = findViewById(R.id.status)
        val pointButton: Button = findViewById(R.id.pointButton)
        val gpsButton: Button = findViewById(R.id.gpsButton)
        val exportButton: Button = findViewById(R.id.exportButton)

        mapView.onCreate(savedInstanceState)
        mapView.getMapAsync { map ->
            map.setStyle(Style.Builder().fromUri("file:///android_asset/map_style.json"))
            map.cameraPosition = org.maplibre.android.camera.CameraPosition.Builder()
                .target(LatLng(15.48, 120.60))
                .zoom(12.0)
                .build()

            map.addOnMapClickListener { latLng ->
                if (drawing) {
                    points.add(latLng)
                    map.addMarker(MarkerOptions().position(latLng).title("P${points.size}"))
                    status.text = "Point P${points.size}: %.7f, %.7f".format(latLng.latitude, latLng.longitude)
                }
                true
            }
        }

        pointButton.setOnClickListener {
            drawing = !drawing
            pointButton.text = if (drawing) "TAP MAP" else "DRAW POINT"
            status.text = if (drawing) "Tap the map to add survey points." else "Drawing paused."
        }

        gpsButton.setOnClickListener { requestGps() }

        exportButton.setOnClickListener {
            if (points.isEmpty()) {
                Toast.makeText(this, "Add at least one point.", Toast.LENGTH_SHORT).show()
            } else {
                val file = DxfWriter.write(points)
                status.text = "DXF saved: ${file.absolutePath}"
                Toast.makeText(this, "DXF exported.", Toast.LENGTH_LONG).show()
            }
        }
    }

    private fun requestGps() {
        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION)
            != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(
                this,
                arrayOf(Manifest.permission.ACCESS_FINE_LOCATION),
                locationRequestCode
            )
            return
        }
        val lm = getSystemService(LOCATION_SERVICE) as android.location.LocationManager
        val provider = android.location.LocationManager.GPS_PROVIDER
        val loc: Location? = lm.getLastKnownLocation(provider)
        if (loc != null) {
            mapView.getMapAsync { map ->
                map.cameraPosition = org.maplibre.android.camera.CameraPosition.Builder()
                    .target(LatLng(loc.latitude, loc.longitude))
                    .zoom(18.0)
                    .build()
                status.text = "GPS: %.7f, %.7f".format(loc.latitude, loc.longitude)
            }
        } else {
            status.text = "No cached GPS fix yet. Go outdoors and try again."
        }
    }

    override fun onStart() { super.onStart(); mapView.onStart() }
    override fun onResume() { super.onResume(); mapView.onResume() }
    override fun onPause() { mapView.onPause(); super.onPause() }
    override fun onStop() { mapView.onStop(); super.onStop() }
    override fun onDestroy() { mapView.onDestroy(); super.onDestroy() }
    override fun onLowMemory() { super.onLowMemory(); mapView.onLowMemory() }

    override fun onSaveInstanceState(outState: Bundle) {
        super.onSaveInstanceState(outState)
        mapView.onSaveInstanceState(outState)
    }
}
