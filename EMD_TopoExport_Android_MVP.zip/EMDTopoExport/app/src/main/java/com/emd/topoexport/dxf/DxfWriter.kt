package com.emd.topoexport.dxf

import android.os.Environment
import org.maplibre.android.geometry.LatLng
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

object DxfWriter {
    fun write(points: List<LatLng>): File {
        val dir = File(
            Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS),
            "EMD TopoExport"
        )
        dir.mkdirs()

        val stamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())
        val file = File(dir, "EMD_Topo_$stamp.dxf")

        // MVP: geographic degrees are preserved as X=longitude, Y=latitude.
        // Production version should transform to the selected projected CRS (e.g. UTM).
        val sb = StringBuilder()
        sb.append("0\nSECTION\n2\nHEADER\n0\nENDSEC\n")
        sb.append("0\nSECTION\n2\nENTITIES\n")

        points.forEachIndexed { i, p ->
            sb.append("0\nPOINT\n8\nEMD_POINTS\n10\n${p.longitude}\n20\n${p.latitude}\n30\n0.0\n")
            sb.append("0\nTEXT\n8\nEMD_LABELS\n10\n${p.longitude}\n20\n${p.latitude}\n30\n0.0\n40\n0.00002\n1\nP${i + 1}\n")
        }

        if (points.size > 1) {
            points.zipWithNext().forEach { (a, b) ->
                sb.append("0\nLINE\n8\nEMD_TRACK\n")
                sb.append("10\n${a.longitude}\n20\n${a.latitude}\n30\n0.0\n")
                sb.append("11\n${b.longitude}\n21\n${b.latitude}\n31\n0.0\n")
            }
        }

        sb.append("0\nENDSEC\n0\nEOF\n")
        file.writeText(sb.toString())
        return file
    }
}
