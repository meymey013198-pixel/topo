# EMD TopoExport Data Sources

## Basemap
### OpenStreetMap
Use OSM for roads, buildings and general map context. The public OSM tile service is appropriate for
interactive viewing only and requires attribution and compliant caching. It must not be used as a bulk
offline tile-download source.

For production scale, use a dedicated commercial OSM-derived provider or self-host the vector tiles.

## Elevation
### Copernicus DEM GLO-30
Global 30 m DEM. Good as a broad regional terrain source, but not engineering-grade survey control.

### Philippines high-resolution data
The production app should support an authorized/licensed NAMRIA/Phil-LiDAR or other Philippine DEM
service when available to the project. Access and redistribution terms must be checked before integration.

## Recommended production architecture

Android:
MapLibre -> map provider
             -> DEM API -> local DEM cache
             -> OSM/vector provider

Server:
DEM ingestion -> reprojection -> contour generation -> GeoJSON/GeoTIFF
DXF service (optional) -> LandXML / DXF / PDF

The app should keep the DEM provider behind an interface so the provider can be changed without
rewriting the map UI.
