# Build the debug APK for realme 14 Pro+

1. Push this project to a GitHub repository.
2. Open the repository's **Actions** tab.
3. Select **EMD TopoExport - Debug APK**.
4. Click **Run workflow**.
5. Wait for `Build Android Debug APK` to finish.
6. Open the completed workflow run.
7. Under **Artifacts**, download:
   `EMD-TopoExport-debug-realme14proplus`
8. Extract the ZIP and install:
   `EMD_TopoExport-debug-realme14proplus.apk`

The APK targets Android API 35, supports Android 8.0+ (minSdk 26), and includes
ARM64 (`arm64-v8a`) and ARM32 (`armeabi-v7a`) native ABI filters. No special
Realme-only APK format is required; a standard Android APK installs on the
realme 14 Pro+.

For installation, Android may ask you to allow installation from the app/file
manager you used to open the APK.
