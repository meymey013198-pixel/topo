# EMD TopoExport Ultimate v1.0
A release-oriented Android field GIS/topographic export application foundation.

The UI is designed around a professional workflow: map -> survey AOI -> terrain/DEM -> coordinate system -> CAD layers -> automatic DXF export.

The project includes release build configuration, R8, signing template, CI workflow, and a modular architecture for real GIS engines.
