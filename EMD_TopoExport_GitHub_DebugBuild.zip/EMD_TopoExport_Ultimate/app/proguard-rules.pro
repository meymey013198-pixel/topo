# TerraTopo release rules
-keep class com.emd.topoexport.** { *; }
