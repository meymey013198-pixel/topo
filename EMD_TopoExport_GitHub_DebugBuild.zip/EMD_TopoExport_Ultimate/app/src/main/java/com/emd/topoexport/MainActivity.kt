package com.emd.topoexport

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

data class SurveyPoint(val id:Int, val name:String, val x:Double, val y:Double, val z:Double)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { EMDTopoApp() }
    }
}

@Composable
fun EMDTopoApp() {
    var screen by remember { mutableStateOf("Map") }
    var contour by remember { mutableStateOf(1) }
    var crs by remember { mutableStateOf("PRS92 / UTM Zone 51N") }
    var exportOpen by remember { mutableStateOf(false) }
    var aoi by remember { mutableStateOf(true) }
    var points by remember { mutableStateOf(listOf(
        SurveyPoint(1,"BM-01",315420.25,1689420.50,124.62),
        SurveyPoint(2,"P-02",315515.40,1689502.10,126.18)
    )) }

    MaterialTheme {
        Scaffold(
            topBar = {
                TopAppBar(
                    title = { Text("EMD TopoExport", fontSize = 20.sp) },
                    actions = { Text("GPS FIX", color = Color(0xFF2E7D32), modifier=Modifier.padding(14.dp)) }
                )
            },
            bottomBar = {
                NavigationBar {
                    listOf("Map","Survey","Terrain","Layers","Export").forEach {
                        NavigationBarItem(
                            selected = screen==it,
                            onClick={screen=it},
                            icon={Text(when(it){"Map"->"⌖";"Survey"->"✚";"Terrain"->"△";"Layers"->"▤";else->"⇩"})},
                            label={Text(it)}
                        )
                    }
                }
            },
            floatingActionButton = {
                FloatingActionButton(onClick={exportOpen=true}) { Text("DXF") }
            }
        ) { pad ->
            Column(Modifier.padding(pad).fillMaxSize()) {
                when(screen) {
                    "Map" -> MapScreen(aoi)
                    "Survey" -> SurveyScreen(points) { points = points + SurveyPoint(points.size+1,"P-${points.size+1}",315600.0+points.size*4,1689600.0+points.size*5,125.0+points.size) }
                    "Terrain" -> TerrainScreen(contour) { contour = if(contour==1) 5 else 1 }
                    "Layers" -> LayersScreen()
                    "Export" -> ExportScreen(crs, contour) { exportOpen=true }
                }
                StatusBar(crs, contour, aoi)
            }
        }
    }

    if(exportOpen) {
        AlertDialog(
            onDismissRequest={exportOpen=false},
            title={Text("Advanced CAD Export")},
            text={Text("DXF 3D • WGS84/UTM • PRS92 • AOI clip • DEM contours with true Z • points • labels • CAD layers\n\nAutomatic project export is prepared for a field-survey workflow.")},
            confirmButton={Button(onClick={exportOpen=false}){Text("EXPORT DXF")}},
            dismissButton={TextButton(onClick={exportOpen=false}){Text("Cancel")}}
        )
    }
}

@Composable fun MapScreen(aoi:Boolean) {
    Box(Modifier.weight(1f).fillMaxWidth().background(Color(0xFFE7EEF2)), contentAlignment=Alignment.Center) {
        Column(horizontalAlignment=Alignment.CenterHorizontally) {
            Text("LIVE GIS / SURVEY MAP", fontSize=22.sp)
            Text("OSM • Satellite • Offline • GPS")
            Spacer(Modifier.height(18.dp))
            Button(onClick={}){Text(if(aoi)"EDIT POLYGON AOI" else "DRAW POLYGON AOI")}
            Spacer(Modifier.height(8.dp))
            OutlinedButton(onClick={}){Text("CAPTURE GPS BOUNDARY")}
        }
    }
}
@Composable fun SurveyScreen(points:List<SurveyPoint>, add:()->Unit) {
    Column(Modifier.weight(1f).fillMaxWidth().padding(14.dp)) {
        Text("FIELD SURVEY", fontSize=22.sp); Spacer(Modifier.height(8.dp))
        Button(onClick=add){Text("ADD SURVEY POINT")}
        LazyColumn { items(points){p -> Card(Modifier.fillMaxWidth().padding(vertical=4.dp)){Row(Modifier.padding(12.dp).fillMaxWidth(), horizontalArrangement=Arrangement.SpaceBetween){Text(p.name);Text("Z %.2f m".format(p.z))}}} }
    }
}
@Composable fun TerrainScreen(contour:Int, change:()->Unit) {
    Column(Modifier.weight(1f).fillMaxWidth().padding(16.dp)) {
        Text("DEM / TERRAIN ENGINE", fontSize=22.sp)
        Spacer(Modifier.height(14.dp))
        Text("Contour interval: ${contour} m")
        Button(onClick=change){Text("CHANGE INTERVAL")}
        Text("DEM clipping: AOI boundary")
        Text("Contour output: projected XY + true elevation Z")
        Text("Major contours, labels, spot elevations")
        Text("Hillshade / slope / aspect analysis")
    }
}
@Composable fun LayersScreen() {
    val layers=listOf("AOI Boundary","Contours","Major Contours","Elevation Points","Spot Elevations","Roads","Buildings","Water","Grid / Coordinates")
    Column(Modifier.weight(1f).fillMaxWidth().padding(16.dp)){Text("CAD / GIS LAYERS",fontSize=22.sp);layers.forEach{Row(Modifier.padding(9.dp)){Checkbox(true,{});Text(it,Modifier.padding(start=8.dp))}}}
}
@Composable fun ExportScreen(crs:String, contour:Int, open:()->Unit) {
    Column(Modifier.weight(1f).fillMaxWidth().padding(16.dp)) {
        Text("EXPORT CENTER",fontSize=22.sp);Spacer(Modifier.height(12.dp))
        Text("CRS: $crs");Text("Contour: ${contour} m");Text("DXF: 3D Z-enabled")
        Text("Automatic output: project/export/")
        Spacer(Modifier.height(20.dp));Button(onClick=open,modifier=Modifier.fillMaxWidth()){Text("EXPORT CAD PACKAGE")}
    }
}
@Composable fun StatusBar(crs:String, contour:Int, aoi:Boolean) {
    Card(Modifier.fillMaxWidth().padding(10.dp),shape=RoundedCornerShape(14.dp)){
        Row(Modifier.padding(12.dp).fillMaxWidth(),horizontalArrangement=Arrangement.SpaceBetween){
            Text("AOI ${if(aoi)"READY" else "NONE"}");Text("1 m");Text(crs.substringBefore(" /"))
        }
    }
}
