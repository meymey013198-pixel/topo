# EMD TopoExport Ultimate Architecture

## Field workflow
GPS/Map -> AOI Polygon -> DEM acquisition/import -> reprojection -> clipping -> terrain analysis -> contour generation -> CAD layer model -> 3D DXF export -> project archive.

## Production engines to connect
- Raster DEM reader/chunker
- Marching-squares contour generator
- CRS transformer with EPSG definitions
- PRS92 / Philippine Grid profiles
- UTM zone detection
- DXF R2013 writer with 3D POLYLINE/LWPOLYLINE + elevation entities
- KML/GeoJSON/CSV/GPX/PDF/GLB writers
- Offline tile cache
- Project database
- Background export jobs
- Integrity/checksum validation

## CAD elevation rule
Contour geometry must be projected into the selected coordinate reference system. Each contour feature receives its actual elevation as Z. Labels are separate CAD text entities.
