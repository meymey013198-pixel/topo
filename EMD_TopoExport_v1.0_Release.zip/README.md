# EMD TopoExport v1.0 Release

Release-oriented Android project for EMD TopoExport.

## Features prepared
- Polygon AOI workflow
- DEM sampling abstraction
- Polygon-masked DEM grid
- Improved marching-squares contour generation with polyline stitching
- 3D DXF export with XYZ elevation
- UTM projection support
- PRS92 projection hook
- Release build type with R8/resource shrinking
- Signing configuration template using environment variables or keystore.properties
- GitHub Actions release build workflow
- Launcher icon resources

## Build locally

1. Install Android Studio with JDK 17 and Android SDK 36.
2. Create a release keystore and keep it private.
3. Copy `keystore.properties.template` to `keystore.properties`.
4. Fill in the keystore values.
5. Run:

    ./gradlew :app:assembleRelease

The release APK is normally written under:
`app/build/outputs/apk/release/`

For Google Play, build an AAB as well:
`./gradlew :app:bundleRelease`

## GitHub Actions

The workflow at `.github/workflows/release.yml` builds the release APK.
For a signed GitHub build, add these repository secrets:
- EMD_KEYSTORE_BASE64
- EMD_KEYSTORE_PASSWORD
- EMD_KEY_ALIAS
- EMD_KEY_PASSWORD

The workflow intentionally does not contain a private signing key.

## Data-source note

The included code uses OpenStreetMap tiles for the development basemap and Open-Meteo elevation for the sample DEM adapter. Production deployments should use services whose licensing, attribution, rate limits, and caching terms are appropriate for the intended use.

## Survey accuracy

Global DEM data is not a substitute for RTK GNSS, total-station observations, or an authoritative high-resolution Philippine elevation/cadastral dataset. Treat the DEM-derived contours as mapping data unless validated against survey control.
