plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

import java.util.Properties

val signingProps = Properties()
val signingFile = rootProject.file("keystore.properties")
if (signingFile.exists()) {
    signingFile.inputStream().use { signingProps.load(it) }
}

android {
    namespace = "com.emd.topoexport"
    compileSdk = 36

    defaultConfig {
        applicationId = "com.emd.topoexport"
        minSdk = 24
        targetSdk = 36
        versionCode = 100
        versionName = "1.0.0"
    }

    signingConfigs {
        create("release") {
            val storeFilePath = System.getenv("EMD_KEYSTORE_FILE") ?: signingProps["storeFile"]?.toString()
            if (!storeFilePath.isNullOrBlank()) {
                storeFile = rootProject.file(storeFilePath)
            }
            storePassword = System.getenv("EMD_KEYSTORE_PASSWORD") ?: signingProps["storePassword"]?.toString()
            keyAlias = System.getenv("EMD_KEY_ALIAS") ?: signingProps["keyAlias"]?.toString()
            keyPassword = System.getenv("EMD_KEY_PASSWORD") ?: signingProps["keyPassword"]?.toString()
        }
    }

    buildTypes {
        debug {
            applicationIdSuffix = ".debug"
            versionNameSuffix = "-debug"
        }
        release {
            isMinifyEnabled = true
            isShrinkResources = true
            signingConfig = signingConfigs.getByName("release")
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro"
            )
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
    }

    packaging {
        resources.excludes += "/META-INF/{AL2.0,LGPL2.1}"
    }
}

dependencies {
    implementation("androidx.core:core-ktx:1.17.0")
    implementation("androidx.appcompat:appcompat:1.7.1")
    implementation("com.google.android.material:material:1.13.0")
    implementation("org.maplibre.gl:android-sdk:13.6.1")
    implementation("org.locationtech.proj4j:proj4j:1.2.3")
    implementation("com.squareup.okhttp3:okhttp:4.12.0")
}
