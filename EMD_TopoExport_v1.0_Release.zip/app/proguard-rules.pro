# EMD TopoExport release rules
-keep class org.maplibre.** { *; }
-keep class org.locationtech.proj4j.** { *; }
-dontwarn org.maplibre.**
-dontwarn org.locationtech.proj4j.**
