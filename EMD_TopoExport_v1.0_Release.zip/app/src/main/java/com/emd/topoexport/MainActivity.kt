package com.emd.topoexport

import android.app.Activity
import android.os.Bundle
import android.widget.TextView

class MainActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val text = TextView(this).apply {
            text = "EMD TopoExport v1.0\n\nRelease architecture initialized.\nDEM • Contours • UTM/PRS92 • 3D DXF"
            textSize = 20f
            setPadding(40, 60, 40, 40)
        }
        setContentView(text)
    }
}
