package com.emd.topoexport.dem

import kotlin.math.floor
import kotlin.math.max
import kotlin.math.min

data class GeoPoint3D(val x: Double, val y: Double, val z: Double)
data class Contour(val elevation: Double, val points: List<GeoPoint3D>)

object ContourGenerator {

    fun generate(
        grid: DemGrid,
        interval: Double,
        originX: Double = grid.lonMin,
        originY: Double = grid.latMin
    ): List<Contour> {
        require(interval > 0)
        val finite = grid.elevations.flatten().filter { it.isFinite() }
        if (finite.isEmpty()) return emptyList()

        val low = floor(finite.min() / interval) * interval
        val high = kotlin.math.ceil(finite.max() / interval) * interval
        val result = mutableListOf<Contour>()

        var level = low
        while (level <= high + interval * 1e-9) {
            val segments = mutableListOf<Pair<GeoPoint3D, GeoPoint3D>>()
            for (r in 0 until grid.rows - 1) for (c in 0 until grid.cols - 1) {
                val z00 = grid.elevations[r][c]
                val z10 = grid.elevations[r][c + 1]
                val z11 = grid.elevations[r + 1][c + 1]
                val z01 = grid.elevations[r + 1][c]
                if (!(z00.isFinite() && z10.isFinite() && z11.isFinite() && z01.isFinite())) continue

                val x0 = originX + (grid.lonMax - grid.lonMin) * c / (grid.cols - 1).coerceAtLeast(1)
                val x1 = originX + (grid.lonMax - grid.lonMin) * (c + 1) / (grid.cols - 1).coerceAtLeast(1)
                val y0 = originY + (grid.latMax - grid.latMin) * r / (grid.rows - 1).coerceAtLeast(1)
                val y1 = originY + (grid.latMax - grid.latMin) * (r + 1) / (grid.rows - 1).coerceAtLeast(1)

                val p00 = GeoPoint3D(x0, y0, z00)
                val p10 = GeoPoint3D(x1, y0, z10)
                val p11 = GeoPoint3D(x1, y1, z11)
                val p01 = GeoPoint3D(x0, y1, z01)

                val edges = listOf(
                    interpolate(p00, p10, level),
                    interpolate(p10, p11, level),
                    interpolate(p11, p01, level),
                    interpolate(p01, p00, level)
                ).filterNotNull()

                when (edges.size) {
                    2 -> segments += edges[0] to edges[1]
                    4 -> {
                        segments += edges[0] to edges[1]
                        segments += edges[2] to edges[3]
                    }
                }
            }
            result += stitch(level, segments)
            level += interval
        }
        return result
    }

    private fun interpolate(a: GeoPoint3D, b: GeoPoint3D, z: Double): GeoPoint3D? {
        val crosses = (a.z <= z && b.z >= z) || (a.z >= z && b.z <= z)
        if (!crosses || a.z == b.z) return null
        val t = (z - a.z) / (b.z - a.z)
        return GeoPoint3D(a.x + (b.x - a.x) * t, a.y + (b.y - a.y) * t, z)
    }

    private fun stitch(level: Double, segments: List<Pair<GeoPoint3D, GeoPoint3D>>): List<Contour> {
        val remaining = segments.toMutableList()
        val output = mutableListOf<Contour>()
        val eps = 1e-10

        fun close(a: GeoPoint3D, b: GeoPoint3D) =
            kotlin.math.abs(a.x - b.x) < eps && kotlin.math.abs(a.y - b.y) < eps

        while (remaining.isNotEmpty()) {
            val first = remaining.removeAt(0)
            val line = mutableListOf(first.first, first.second)
            var changed = true
            while (changed) {
                changed = false
                val tail = line.last()
                val head = line.first()
                val idxTail = remaining.indexOfFirst { close(it.first, tail) || close(it.second, tail) }
                if (idxTail >= 0) {
                    val s = remaining.removeAt(idxTail)
                    line += if (close(s.first, tail)) s.second else s.first
                    changed = true
                    continue
                }
                val idxHead = remaining.indexOfFirst { close(it.first, head) || close(it.second, head) }
                if (idxHead >= 0) {
                    val s = remaining.removeAt(idxHead)
                    line.add(0, if (close(s.first, head)) s.second else s.first)
                    changed = true
                }
            }
            if (line.size >= 2) output += Contour(level, line)
        }
        return output
    }
}
