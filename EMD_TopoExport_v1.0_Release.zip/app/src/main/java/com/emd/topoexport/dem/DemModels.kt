package com.emd.topoexport.dem

data class DemGrid(
    val rows: Int,
    val cols: Int,
    val latMin: Double,
    val lonMin: Double,
    val latMax: Double,
    val lonMax: Double,
    val elevations: Array<DoubleArray>,
    val valid: Array<BooleanArray>
)

data class DemPoint(val lat: Double, val lon: Double, val elevation: Double)
