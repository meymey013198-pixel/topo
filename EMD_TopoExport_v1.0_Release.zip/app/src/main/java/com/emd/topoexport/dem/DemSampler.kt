package com.emd.topoexport.dem

import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONObject

class DemSampler(private val client: OkHttpClient = OkHttpClient()) {

    fun sample(
        polygon: List<Pair<Double, Double>>,
        rows: Int,
        cols: Int
    ): DemGrid {
        require(polygon.size >= 3)
        val latMin = polygon.minOf { it.second }
        val latMax = polygon.maxOf { it.second }
        val lonMin = polygon.minOf { it.first }
        val lonMax = polygon.maxOf { it.first }

        val points = mutableListOf<Pair<Int, Int>>()
        val coords = mutableListOf<Pair<Double, Double>>()
        val elevations = Array(rows) { DoubleArray(cols) { Double.NaN } }
        val valid = Array(rows) { BooleanArray(cols) }

        for (r in 0 until rows) for (c in 0 until cols) {
            val lon = lonMin + (lonMax - lonMin) * c / (cols - 1).coerceAtLeast(1)
            val lat = latMin + (latMax - latMin) * r / (rows - 1).coerceAtLeast(1)
            if (PolygonMask.contains(lon, lat, polygon)) {
                points += r to c
                coords += lat to lon
            }
        }

        // Open-Meteo accepts batches; keep requests below its documented practical limits.
        for (chunk in coords.chunked(100)) {
            if (chunk.isEmpty()) continue
            val lats = chunk.joinToString(",") { it.first.toString() }
            val lons = chunk.joinToString(",") { it.second.toString() }
            val url = "https://api.open-meteo.com/v1/elevation?latitude=$lats&longitude=$lons"
            val body = client.newCall(Request.Builder().url(url).build()).execute().use { it.body?.string() ?: "{}" }
            val arr = JSONObject(body).optJSONArray("elevation") ?: continue
            chunk.forEachIndexed { idx, ll ->
                val r = ((ll.first - latMin) / (latMax - latMin).coerceAtLeast(1e-15) * (rows - 1)).roundToIntSafe()
                val c = ((ll.second - lonMin) / (lonMax - lonMin).coerceAtLeast(1e-15) * (cols - 1)).roundToIntSafe()
                if (r in 0 until rows && c in 0 until cols) {
                    elevations[r][c] = arr.optDouble(idx, Double.NaN)
                    valid[r][c] = elevations[r][c].isFinite()
                }
            }
        }
        return DemGrid(rows, cols, latMin, lonMin, latMax, lonMax, elevations, valid)
    }

    private fun Double.roundToIntSafe(): Int = kotlin.math.round(this).toInt()
}
