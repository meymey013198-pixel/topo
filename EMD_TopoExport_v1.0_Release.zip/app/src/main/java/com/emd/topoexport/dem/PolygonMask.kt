package com.emd.topoexport.dem

object PolygonMask {
    fun contains(x: Double, y: Double, polygon: List<Pair<Double, Double>>): Boolean {
        if (polygon.size < 3) return false
        var inside = false
        var j = polygon.lastIndex
        for (i in polygon.indices) {
            val xi = polygon[i].first
            val yi = polygon[i].second
            val xj = polygon[j].first
            val yj = polygon[j].second
            val crosses = (yi > y) != (yj > y)
            if (crosses) {
                val xAtY = (xj - xi) * (y - yi) / ((yj - yi).takeIf { it != 0.0 } ?: 1e-15) + xi
                if (x < xAtY) inside = !inside
            }
            j = i
        }
        return inside
    }
}
