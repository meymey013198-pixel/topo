package com.emd.topoexport.export

import com.emd.topoexport.dem.Contour
import com.emd.topoexport.dem.GeoPoint3D
import java.io.File
import java.util.Locale

class DxfWriter {

    fun write(
        file: File,
        contours: List<Contour>,
        demPoints: List<GeoPoint3D>,
        boundary: List<GeoPoint3D>,
        includeLabels: Boolean = true
    ) {
        file.parentFile?.mkdirs()
        file.bufferedWriter().use { out ->
            fun pair(a: Any, b: Any) {
                out.append(a.toString()).append('\n').append(b.toString()).append('\n')
            }
            pair(0, "SECTION"); pair(2, "HEADER")
            pair(9, "\$ACADVER"); pair(1, "AC1015")
            pair(0, "ENDSEC")
            pair(0, "SECTION"); pair(2, "ENTITIES")

            demPoints.forEach {
                pair(0, "POINT")
                pair(8, "DEM_POINTS")
                pair(10, fmt(it.x)); pair(20, fmt(it.y)); pair(30, fmt(it.z))
            }

            if (boundary.size >= 2) polyline(out, boundary, "AOI_BOUNDARY", true)

            contours.forEachIndexed { idx, contour ->
                polyline(out, contour.points, "CONTOUR_${idx + 1}", false)
                if (includeLabels && contour.points.isNotEmpty()) {
                    val p = contour.points[contour.points.size / 2]
                    pair(0, "TEXT"); pair(8, "CONTOUR_LABELS")
                    pair(10, fmt(p.x)); pair(20, fmt(p.y)); pair(30, fmt(p.z))
                    pair(40, "2.5"); pair(1, String.format(Locale.US, "%.2f", contour.elevation))
                    pair(50, "0")
                }
            }

            pair(0, "ENDSEC"); pair(0, "EOF")
        }
    }

    private fun polyline(out: java.io.BufferedWriter, pts: List<GeoPoint3D>, layer: String, closed: Boolean) {
        fun p(a: Any, b: Any) {
            out.append(a.toString()).append('\n').append(b.toString()).append('\n')
        }
        p(0, "POLYLINE"); p(8, layer); p(66, 1); p(70, if (closed) 33 else 32)
        pts.forEach {
            p(0, "VERTEX"); p(8, layer)
            p(10, fmt(it.x)); p(20, fmt(it.y)); p(30, fmt(it.z))
        }
        p(0, "SEQEND")
    }

    private fun fmt(v: Double) = String.format(Locale.US, "%.3f", v)
}
