package com.emd.topoexport.project

data class ProjectSettings(
    val crsMode: String = "UTM",
    val utmZone: Int = 51,
    val prs92Zone: Int = 3,
    val contourIntervalMeters: Double = 1.0,
    val demRows: Int = 40,
    val demCols: Int = 40
)
