package com.emd.topoexport.projection

import org.locationtech.proj4j.CRSFactory
import org.locationtech.proj4j.CoordinateReferenceSystem
import org.locationtech.proj4j.CoordinateTransform
import org.locationtech.proj4j.CoordinateTransformFactory
import org.locationtech.proj4j.ProjCoordinate

object Crs {
    private val factory = CRSFactory()
    private val tf = CoordinateTransformFactory()

    fun utm(zone: Int, north: Boolean = true): CoordinateReferenceSystem =
        factory.createFromParameters(
            "UTM$zone",
            "+proj=utm +zone=$zone ${if (north) "+north" else "+south"} +datum=WGS84 +units=m +no_defs"
        )

    // PRS92 / Philippines zone definitions retained as an explicit project hook.
    // Verify the authoritative EPSG/PRS92 realization for the intended survey jurisdiction before engineering use.
    fun prs92(zone: Int): CoordinateReferenceSystem {
        val cm = when (zone) {
            1 -> 117.0
            2 -> 119.0
            3 -> 121.0
            4 -> 123.0
            5 -> 125.0
            else -> error("PRS92 zone must be 1..5")
        }
        return factory.createFromParameters(
            "PRS92-$zone",
            "+proj=tmerc +lat_0=0 +lon_0=$cm +k=0.99995 +x_0=500000 +y_0=0 +ellps=clrk66 +towgs84=-127.62,-67.24,-47.04,0,0,0,0 +units=m +no_defs"
        )
    }

    fun transform(crs: CoordinateReferenceSystem, lon: Double, lat: Double): ProjCoordinate {
        val source = factory.createFromName("EPSG:4326")
        val transform: CoordinateTransform = tf.createTransform(source, crs)
        return transform.transform(ProjCoordinate(lon, lat), ProjCoordinate())
    }
}
