# Release checklist

- [ ] Replace launcher artwork if a final EMD logo is available.
- [ ] Create a private release/upload keystore.
- [ ] Store signing secrets only in GitHub Actions Secrets or a secure CI vault.
- [ ] Confirm map provider licensing/attribution and tile usage.
- [ ] Confirm DEM source licensing and intended accuracy.
- [ ] Validate UTM/PRS92 transformations against authoritative control points.
- [ ] Test polygon AOI edge cases.
- [ ] Test missing/invalid DEM cells.
- [ ] Open exported DXF in AutoCAD/Civil 3D and verify XYZ elevations.
- [ ] Test on the target Android phones.
- [ ] Build signed APK and AAB.
- [ ] Increase versionCode for every subsequent release.
