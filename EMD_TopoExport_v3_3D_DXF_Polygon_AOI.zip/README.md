# EMD TopoExport v0.3

## Major upgrade

### Polygon AOI
- Tap POLYGON AOI.
- Tap as many vertices as needed.
- Tap CLOSE AOI.
- The polygon is drawn on the map.
- DEM samples outside the polygon are masked out.
- The polygon boundary can be exported.

### Elevation in DXF
The export is now a **3D DXF**:
- DEM sample points use X=projected Easting, Y=projected Northing, Z=elevation.
- Contours are AutoCAD 3D POLYLINE entities with each vertex carrying the contour elevation as Z.
- AOI boundary is exported as a 3D polyline.
- Contour labels carry the contour elevation.

This means the elevation is not merely a text attribute; it is written into the DXF geometry's Z coordinate.

### Coordinate systems
- UTM AUTO
- UTM zones 47–51
- PRS92 AUTO
- PRS92 zones 1–5

PRS92 uses the EPSG definitions for Philippines zones 1–5 (EPSG 3121–3125), including the
official PRS92-to-WGS84 transformation parameters. Verify the required datum transformation
for a particular survey before engineering/cadastral use.

### DEM/contours
The MVP still uses a sampled elevation API and a 10×10 grid because the online elevation
request is limited in size. The polygon masks the grid to the AOI. Contours are generated
with marching squares.

For a production version, replace the elevation adapter with a real raster DEM/COG source.
That will allow native-resolution sampling, larger AOIs, better contour connectivity,
smoothing/generalization, index contours, and terrain surface generation.

### DWG
The application exports DXF directly. DXF is the open CAD interchange format used here for
3D survey geometry. Native DWG writing requires a DWG-compatible SDK/library; the 3D DXF can
be opened in AutoCAD/Civil 3D and saved as DWG.
