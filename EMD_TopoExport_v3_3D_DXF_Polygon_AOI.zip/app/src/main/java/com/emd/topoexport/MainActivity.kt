package com.emd.topoexport

import android.graphics.Color
import android.os.Bundle
import android.widget.*
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import com.emd.topoexport.dem.ContourGenerator
import com.emd.topoexport.dem.ElevationApi
import com.emd.topoexport.export.DxfWriter
import com.emd.topoexport.geom.PolygonUtils
import com.emd.topoexport.model.*
import org.maplibre.android.MapLibre
import org.maplibre.android.annotations.PolygonOptions
import org.maplibre.android.annotations.PolylineOptions
import org.maplibre.android.geometry.LatLng
import org.maplibre.android.maps.MapView
import org.maplibre.android.maps.Style
import java.util.concurrent.Executors

class MainActivity : AppCompatActivity() {
    private lateinit var mapView: MapView
    private lateinit var status: TextView
    private val exec = Executors.newSingleThreadExecutor()
    private var polygonMode = false
    private val boundary = mutableListOf<LatLng>()
    private var demGrid: Array<Array<ElevationPoint?>>? = null
    private var demPoints = emptyList<ElevationPoint>()
    private var contours = emptyList<ContourLine>()
    private var settings = ExportSettings()
    private var map: org.maplibre.android.maps.MapLibreMap? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        MapLibre.getInstance(this)
        setContentView(R.layout.activity_main)
        mapView = findViewById(R.id.mapView)
        status = findViewById(R.id.status)
        mapView.onCreate(savedInstanceState)

        val areaButton: Button = findViewById(R.id.areaButton)
        val terrainButton: Button = findViewById(R.id.terrainButton)
        val settingsButton: Button = findViewById(R.id.settingsButton)
        val exportButton: Button = findViewById(R.id.exportButton)

        mapView.getMapAsync { m ->
            map = m
            m.setStyle(Style.Builder().fromUri("file:///android_asset/map_style.json"))
            m.cameraPosition = org.maplibre.android.camera.CameraPosition.Builder()
                .target(LatLng(15.48,120.60)).zoom(12.0).build()

            m.addOnMapClickListener { p ->
                if (polygonMode) {
                    boundary.add(p)
                    status.text = "AOI vertex ${boundary.size}. Tap more vertices; tap AREA again to close."
                    drawBoundary()
                }
                true
            }
        }

        areaButton.setOnClickListener {
            if (!polygonMode && boundary.size >= 3) {
                // Re-entering AREA with a finished polygon clears it for a new AOI.
                boundary.clear()
                demGrid = null
                demPoints = emptyList()
                contours = emptyList()
            }
            polygonMode = !polygonMode
            areaButton.text = if (polygonMode) "CLOSE AOI" else "AREA"
            status.text = if (polygonMode)
                "Tap polygon vertices. Press CLOSE AOI when finished."
            else
                if (boundary.size >= 3) "AOI closed. Tap DEM."
                else "Add at least 3 vertices."
            if (!polygonMode && boundary.size >= 3) drawBoundary()
        }

        terrainButton.setOnClickListener { buildDem() }
        settingsButton.setOnClickListener { showSettings() }
        exportButton.setOnClickListener { exportDxf() }
    }

    private fun drawBoundary() {
        val m = map ?: return
        if (boundary.size >= 2) {
            m.addPolyline(
                PolylineOptions().addAll(boundary + boundary.first())
                    .color(Color.rgb(20,80,220)).width(4f)
            )
        }
        if (boundary.size >= 3) {
            m.addPolygon(
                PolygonOptions().addAll(boundary)
                    .fillColor(Color.argb(45,40,110,220))
                    .strokeColor(Color.rgb(20,80,220)).strokeWidth(3f)
            )
        }
    }

    private fun buildDem() {
        if (boundary.size < 3 || polygonMode) {
            Toast.makeText(this, "Finish a polygon AOI first.", Toast.LENGTH_SHORT).show()
            return
        }

        val bounds = PolygonUtils.bounds(boundary.map {
            ElevationPoint(it.latitude,it.longitude,Double.NaN)
        })
        val south=bounds[0]; val north=bounds[1]; val west=bounds[2]; val east=bounds[3]

        // 10x10 = 100 samples, fitting the MVP elevation endpoint request limit.
        val n = 10
        status.text = "Sampling DEM inside polygon…"
        exec.execute {
            try {
                val samples = Array(n) { r ->
                    Array(n) { c ->
                        val lat = south + (north-south)*r/(n-1)
                        val lon = west + (east-west)*c/(n-1)
                        if (PolygonUtils.contains(lat,lon,boundary.map {
                                ElevationPoint(it.latitude,it.longitude,Double.NaN)
                            })) ElevationPoint(lat,lon,Double.NaN) else null
                    }
                }

                val valid = samples.flatMap { it.asList() }.filterNotNull()
                if (valid.isEmpty()) throw IllegalArgumentException("Polygon contains no DEM sample cells.")

                val elevated = ElevationApi.getElevations(valid)
                var k=0
                val grid = Array(n) { r ->
                    Array(n) {
                        val cell=samples[r][it]
                        if (cell == null) null else elevated[k++]
                    }
                }

                val lines = ContourGenerator.generate(grid, settings.contourInterval)
                demGrid=grid
                demPoints=elevated
                contours=lines

                runOnUiThread {
                    status.text = "DEM ready: ${elevated.size} points, ${lines.size} 3D contour segments, CRS ${settings.crs}"
                    drawContours(lines)
                }
            } catch(e:Exception) {
                runOnUiThread { status.text="DEM error: ${e.message}" }
            }
        }
    }

    private fun drawContours(lines: List<ContourLine>) {
        map?.let { m ->
            lines.forEach { line ->
                if(line.points.size>=2)
                    m.addPolyline(
                        PolylineOptions().addAll(line.points.map{LatLng(it.lat,it.lon)})
                            .color(Color.rgb(180,80,30)).width(2f)
                    )
            }
        }
    }

    private fun showSettings() {
        val layout=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(30,10,30,10)}
        val crs=Spinner(this)
        val opts=arrayOf("UTM AUTO","UTM 47","UTM 48","UTM 49","UTM 50","UTM 51",
            "PRS92 AUTO","PRS92 1","PRS92 2","PRS92 3","PRS92 4","PRS92 5")
        crs.adapter=ArrayAdapter(this,android.R.layout.simple_spinner_dropdown_item,opts)
        crs.setSelection(opts.indexOf(settings.crs).coerceAtLeast(0))

        val interval=EditText(this).apply{
            hint="Contour interval (m)"
            inputType=android.text.InputType.TYPE_CLASS_NUMBER or android.text.InputType.TYPE_NUMBER_FLAG_DECIMAL
            setText(settings.contourInterval.toString())
        }
        val dem=CheckBox(this).apply{text="Export 3D DEM points";isChecked=settings.includeDemPoints}
        val con=CheckBox(this).apply{text="Export 3D contours";isChecked=settings.includeContours}
        val aoi=CheckBox(this).apply{text="Export 3D AOI boundary";isChecked=settings.includeBoundary}
        val lab=CheckBox(this).apply{text="Export contour elevation labels";isChecked=settings.includeLabels}
        layout.addView(TextView(this).apply{text="Coordinate system"})
        layout.addView(crs);layout.addView(interval);layout.addView(dem);layout.addView(con);layout.addView(aoi);layout.addView(lab)

        AlertDialog.Builder(this).setTitle("Export / DEM Settings").setView(layout)
            .setPositiveButton("SAVE"){_,_->
                settings=ExportSettings(
                    crs=crs.selectedItem.toString(),
                    contourInterval=interval.text.toString().toDoubleOrNull()?.takeIf{it>0}?:5.0,
                    includeDemPoints=dem.isChecked,includeContours=con.isChecked,
                    includeBoundary=aoi.isChecked,includeLabels=lab.isChecked
                )
                status.text="Settings saved: ${settings.crs}; contour ${settings.contourInterval} m."
            }.setNegativeButton("CANCEL",null).show()
    }

    private fun exportDxf() {
        if(demPoints.isEmpty()){
            Toast.makeText(this,"Generate DEM first.",Toast.LENGTH_SHORT).show();return
        }
        status.text="Exporting 3D DXF…"
        exec.execute {
            try {
                val poly=boundary.map{ElevationPoint(it.latitude,it.longitude,0.0)}
                val file=DxfWriter.write(demPoints,contours,poly,settings)
                runOnUiThread{
                    status.text="3D DXF saved: Downloads/EMD TopoExport/${file.name}"
                    Toast.makeText(this,"3D DXF export complete.",Toast.LENGTH_LONG).show()
                }
            }catch(e:Exception){runOnUiThread{status.text="Export error: ${e.message}"}}
        }
    }

    override fun onStart(){super.onStart();mapView.onStart()}
    override fun onResume(){super.onResume();mapView.onResume()}
    override fun onPause(){mapView.onPause();super.onPause()}
    override fun onStop(){mapView.onStop();super.onStop()}
    override fun onDestroy(){mapView.onDestroy();exec.shutdown();super.onDestroy()}
    override fun onLowMemory(){super.onLowMemory();mapView.onLowMemory()}
    override fun onSaveInstanceState(out:Bundle){super.onSaveInstanceState(out);mapView.onSaveInstanceState(out)}
}
