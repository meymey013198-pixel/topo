package com.emd.topoexport.crs

import org.locationtech.proj4j.CRSFactory
import org.locationtech.proj4j.CoordinateReferenceSystem
import org.locationtech.proj4j.CoordinateTransformFactory
import org.locationtech.proj4j.ProjCoordinate

object Crs {
    private val factory = CRSFactory()
    private val tf = CoordinateTransformFactory()

    fun utmForLon(lon: Double): Int =
        kotlin.math.floor((lon + 180.0) / 6.0).toInt() + 1

    fun utmName(lon: Double): String = "EPSG:${32600 + utmForLon(lon)}"

    private fun prs92(zone: Int): CoordinateReferenceSystem {
        // EPSG 3121–3125: PRS92 / Philippines zones 1–5.
        // Central meridians are 117,119,121,123,125 degrees.
        val cm = 117.0 + (zone - 1) * 2.0
        val proj = "+proj=tmerc +lat_0=0 +lon_0=$cm +k=0.99995 " +
                "+x_0=500000 +y_0=0 +ellps=clrk66 " +
                "+towgs84=-127.62,-67.24,-47.04,3.068,-4.903,-1.578,-1.06 " +
                "+units=m +no_defs +type=crs"
        return factory.createFromParameters("EPSG:${3120 + zone}", proj)
    }

    fun transform(lat: Double, lon: Double, target: String): ProjCoordinate {
        val src = factory.createFromName("EPSG:4326")
        val dst = when {
            target == "UTM AUTO" -> factory.createFromName(utmName(lon))
            target == "PRS92 AUTO" -> prs92(
                when {
                    lon < 118.0 -> 1
                    lon < 120.0 -> 2
                    lon < 122.0 -> 3
                    lon < 124.0 -> 4
                    else -> 5
                }
            )
            target.startsWith("UTM ") ->
                factory.createFromName("EPSG:${32600 + target.substringAfter("UTM ").toInt()}")
            target.startsWith("PRS92 ") ->
                prs92(target.substringAfter("PRS92 ").toInt())
            else -> src
        }
        return tf.createTransform(src, dst).transform(
            ProjCoordinate(lon, lat), ProjCoordinate()
        )
    }
}
