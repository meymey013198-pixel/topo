package com.emd.topoexport.dem

import com.emd.topoexport.model.ContourLine
import com.emd.topoexport.model.ElevationPoint
import kotlin.math.ceil

object ContourGenerator {
    fun generate(grid: Array<Array<ElevationPoint?>>, interval: Double): List<ContourLine> {
        val rows = grid.size
        val cols = grid[0].size
        val valid = grid.flatMap { it.asList() }.filterNotNull()
        if (valid.isEmpty() || interval <= 0) return emptyList()

        val minZ = valid.minOf { it.z }
        val maxZ = valid.maxOf { it.z }
        val result = mutableListOf<ContourLine>()
        var level = ceil(minZ / interval) * interval

        while (level <= maxZ + 1e-9) {
            for (r in 0 until rows - 1) {
                for (c in 0 until cols - 1) {
                    val a = grid[r][c]
                    val b = grid[r][c + 1]
                    val d = grid[r + 1][c]
                    val cc = grid[r + 1][c + 1]
                    if (a == null || b == null || d == null || cc == null) continue

                    fun cross(p: ElevationPoint, q: ElevationPoint): ElevationPoint? {
                        if ((p.z < level && q.z < level) ||
                            (p.z > level && q.z > level) ||
                            p.z == q.z) return null
                        val t = (level - p.z) / (q.z - p.z)
                        return ElevationPoint(
                            p.lat + t * (q.lat - p.lat),
                            p.lon + t * (q.lon - p.lon),
                            level
                        )
                    }

                    val e = listOf(
                        cross(a,b), cross(b,cc), cross(cc,d), cross(d,a)
                    ).filterNotNull()

                    if (e.size >= 2) {
                        result += ContourLine(level, listOf(e[0], e[1]))
                        if (e.size == 4) result += ContourLine(level, listOf(e[2], e[3]))
                    }
                }
            }
            level += interval
        }
        return result
    }
}
