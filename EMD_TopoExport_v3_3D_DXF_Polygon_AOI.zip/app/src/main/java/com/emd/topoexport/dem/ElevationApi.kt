package com.emd.topoexport.dem

import com.emd.topoexport.model.ElevationPoint
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONObject

object ElevationApi {
    private val client = OkHttpClient()

    fun getElevations(points: List<ElevationPoint>): List<ElevationPoint> {
        if (points.isEmpty()) return emptyList()
        val lat = points.joinToString(",") { "%.7f".format(java.util.Locale.US, it.lat) }
        val lon = points.joinToString(",") { "%.7f".format(java.util.Locale.US, it.lon) }
        val url = "https://api.open-meteo.com/v1/elevation?latitude=$lat&longitude=$lon"
        val request = Request.Builder().url(url).build()
        client.newCall(request).execute().use { response ->
            if (!response.isSuccessful) error("Elevation service HTTP ${response.code}")
            val arr = JSONObject(response.body!!.string()).getJSONArray("elevation")
            return points.mapIndexed { i, p -> p.copy(z = arr.getDouble(i)) }
        }
    }
}
