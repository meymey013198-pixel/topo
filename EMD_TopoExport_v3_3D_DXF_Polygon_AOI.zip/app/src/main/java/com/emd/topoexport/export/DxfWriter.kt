package com.emd.topoexport.export

import android.os.Environment
import com.emd.topoexport.crs.Crs
import com.emd.topoexport.model.ContourLine
import com.emd.topoexport.model.ElevationPoint
import com.emd.topoexport.model.ExportSettings
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

object DxfWriter {
    private fun header(sb: StringBuilder) {
        sb.append("0\nSECTION\n2\nHEADER\n")
        sb.append("9\n$ACADVER\n1\nAC1015\n")
        sb.append("0\nENDSEC\n0\nSECTION\n2\nENTITIES\n")
    }

    private fun end(sb: StringBuilder) {
        sb.append("0\nENDSEC\n0\nEOF\n")
    }

    private fun point(sb: StringBuilder, p: ElevationPoint, layer: String, crs: String) {
        val xy = Crs.transform(p.lat, p.lon, crs)
        sb.append("0\nPOINT\n8\n$layer\n10\n${xy.x}\n20\n${xy.y}\n30\n${p.z}\n")
    }

    // AutoCAD 3D POLYLINE with VERTEX Z values.
    private fun poly3d(sb: StringBuilder, points: List<ElevationPoint>, layer: String, crs: String) {
        if (points.size < 2) return
        sb.append("0\nPOLYLINE\n8\n$layer\n66\n1\n70\n8\n")
        points.forEach { p ->
            val xy = Crs.transform(p.lat, p.lon, crs)
            sb.append("0\nVERTEX\n8\n$layer\n10\n${xy.x}\n20\n${xy.y}\n30\n${p.z}\n70\n32\n")
        }
        sb.append("0\nSEQEND\n")
    }

    fun write(
        demPoints: List<ElevationPoint>,
        contours: List<ContourLine>,
        boundary: List<ElevationPoint>,
        settings: ExportSettings
    ): File {
        val dir = File(
            Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS),
            "EMD TopoExport"
        )
        dir.mkdirs()
        val stamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())
        val file = File(dir, "EMD_Topo_3D_$stamp.dxf")

        val sb = StringBuilder()
        header(sb)

        if (settings.includeDemPoints) {
            demPoints.filter { !it.z.isNaN() }.forEach {
                point(sb, it, settings.demLayer, settings.crs)
            }
        }

        if (settings.includeContours) {
            contours.forEach {
                poly3d(sb, it.points, settings.contourLayer, settings.crs)
            }
        }

        if (settings.includeBoundary && boundary.size >= 3) {
            poly3d(sb, boundary + boundary.first(), settings.boundaryLayer, settings.crs)
        }

        if (settings.includeLabels) {
            contours.groupBy { it.elevation }.forEach { (z, lines) ->
                val p = lines.firstOrNull()?.points?.firstOrNull() ?: return@forEach
                val xy = Crs.transform(p.lat,p.lon,settings.crs)
                sb.append("0\nTEXT\n8\nEMD_CONTOUR_LABELS\n10\n${xy.x}\n20\n${xy.y}\n30\n$z\n40\n1.5\n1\n${"%.2f".format(Locale.US,z)}\n")
            }
        }

        end(sb)
        file.writeText(sb.toString())
        return file
    }
}
