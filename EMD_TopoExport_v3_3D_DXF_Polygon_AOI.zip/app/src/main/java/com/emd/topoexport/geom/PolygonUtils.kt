package com.emd.topoexport.geom

import com.emd.topoexport.model.ElevationPoint

object PolygonUtils {
    fun contains(lat: Double, lon: Double, polygon: List<ElevationPoint>): Boolean {
        if (polygon.size < 3) return false
        var inside = false
        var j = polygon.lastIndex
        for (i in polygon.indices) {
            val yi = polygon[i].lat
            val xi = polygon[i].lon
            val yj = polygon[j].lat
            val xj = polygon[j].lon
            val crosses = ((yi > lat) != (yj > lat)) &&
                    (lon < (xj - xi) * (lat - yi) / ((yj - yi).takeIf { it != 0.0 } ?: 1e-15) + xi)
            if (crosses) inside = !inside
            j = i
        }
        return inside
    }

    fun bounds(poly: List<ElevationPoint>): DoubleArray {
        val south = poly.minOf { it.lat }
        val north = poly.maxOf { it.lat }
        val west = poly.minOf { it.lon }
        val east = poly.maxOf { it.lon }
        return doubleArrayOf(south,north,west,east)
    }
}
