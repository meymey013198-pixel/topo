package com.emd.topoexport.model

data class ElevationPoint(val lat: Double, val lon: Double, val z: Double)

data class ContourLine(val elevation: Double, val points: List<ElevationPoint>)

data class ExportSettings(
    val crs: String = "UTM AUTO",
    val contourInterval: Double = 5.0,
    val includeDemPoints: Boolean = true,
    val includeContours: Boolean = true,
    val includeBoundary: Boolean = true,
    val includeLabels: Boolean = true,
    val contourLayer: String = "EMD_CONTOURS",
    val demLayer: String = "EMD_DEM_POINTS",
    val boundaryLayer: String = "EMD_AOI"
)
